# Zork Ruby

I'm learning Ruby. To do that, I thought I'd build a replica of Zork, a game I love!

Currently, here are the moves you can make:
* `go north`
* `go south`
* `go east`
* `go west`

You can gracefully exit the game by typing `\quit`.

How to play:
* Download the project files
* Install Ruby 1.9.3 - should work with 2.0.0 as well
* Run `ruby zork.rb`

More to come, hopefully :-)